// ========================================
// Calbright Design System - Navigation & Interactivity
// ========================================

document.addEventListener('DOMContentLoaded', () => {
  // Sidebar navigation active state on scroll
  const sections = document.querySelectorAll('.section[id]');
  const navLinks = document.querySelectorAll('.sidebar-nav a');

  const observerOptions = {
    rootMargin: '-80px 0px -60% 0px',
    threshold: 0
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        navLinks.forEach(link => link.classList.remove('active'));
        const activeLink = document.querySelector(`.sidebar-nav a[href="#${entry.target.id}"]`);
        if (activeLink) activeLink.classList.add('active');
      }
    });
  }, observerOptions);

  sections.forEach(section => observer.observe(section));

  // Smooth scroll for nav links
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('href').substring(1);
      const targetSection = document.getElementById(targetId);
      if (targetSection) {
        targetSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Search box demo interaction
  const searchInputs = document.querySelectorAll('.search-input');
  searchInputs.forEach(input => {
    const results = input.parentElement.querySelector('.search-results');
    if (results) {
      input.addEventListener('focus', () => {
        if (input.value.length > 0) results.classList.add('show');
      });
      input.addEventListener('input', () => {
        if (input.value.length > 0) {
          results.classList.add('show');
        } else {
          results.classList.remove('show');
        }
      });
      input.addEventListener('blur', () => {
        setTimeout(() => results.classList.remove('show'), 200);
      });
    }
  });

  // Tab switching
  document.querySelectorAll('[data-tabs]').forEach(tabContainer => {
    const navItems = tabContainer.querySelectorAll('.tabs-nav-item');
    const contentPanels = tabContainer.querySelectorAll('.tab-panel');

    navItems.forEach((item, index) => {
      item.addEventListener('click', () => {
        navItems.forEach(n => n.classList.remove('active'));
        contentPanels.forEach(p => p.style.display = 'none');
        item.classList.add('active');
        if (contentPanels[index]) contentPanels[index].style.display = 'block';
      });
    });
  });

  // Message dismiss
  document.querySelectorAll('.message-dismiss').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.parentElement.style.display = 'none';
    });
  });

  // Rating interaction
  document.querySelectorAll('.rating').forEach(rating => {
    const stars = rating.querySelectorAll('.rating-star, .rating-heart');
    stars.forEach((star, index) => {
      star.addEventListener('click', () => {
        stars.forEach((s, i) => {
          if (i <= index) {
            s.classList.add('active');
          } else {
            s.classList.remove('active');
          }
        });
      });
    });
  });

  // Progress bar animation on scroll
  const progressBars = document.querySelectorAll('.progress-bar[data-width]');
  const progressObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.width = entry.target.dataset.width;
        progressObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });

  progressBars.forEach(bar => {
    bar.style.width = '0%';
    progressObserver.observe(bar);
  });

  // Toggle interaction
  document.querySelectorAll('.form-toggle').forEach(toggle => {
    toggle.addEventListener('change', () => {
      const label = toggle.parentElement.querySelector('.toggle-label');
      if (label) {
        label.textContent = toggle.checked ? 'On' : 'Off';
      }
    });
  });

  // Code block toggle
  document.querySelectorAll('.code-block-header').forEach(header => {
    header.addEventListener('click', () => {
      const body = header.nextElementSibling;
      const expanded = header.getAttribute('aria-expanded') === 'true';
      header.setAttribute('aria-expanded', !expanded);
      body.classList.toggle('show');
    });
  });

  // Nav demo item click - toggle active without jumping
  document.querySelectorAll('.nav-demo .nav-items').forEach(navGroup => {
    navGroup.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        // Clear all inline styles and active class in this nav group
        navGroup.querySelectorAll('.nav-item').forEach(n => {
          n.classList.remove('active');
          n.removeAttribute('style');
        });
        item.classList.add('active');
      });
    });
  });

  // Mobile nav demo - expandable items
  document.querySelectorAll('.mobile-nav-expandable').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const subitems = link.nextElementSibling;
      if (subitems && subitems.classList.contains('mobile-nav-subitems')) {
        const isOpen = link.classList.contains('expanded');
        // Close all other expanded items
        document.querySelectorAll('.mobile-nav-expandable.expanded').forEach(other => {
          if (other !== link) {
            other.classList.remove('expanded');
            other.nextElementSibling.style.display = 'none';
          }
        });
        // Toggle current
        link.classList.toggle('expanded');
        subitems.style.display = isOpen ? 'none' : 'block';
      }
    });
  });

  // Mobile nav sub items - click to select
  document.querySelectorAll('.mobile-nav-items').forEach(container => {
    container.querySelectorAll('.mobile-nav-link:not(.mobile-nav-expandable), .mobile-nav-sub').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        container.querySelectorAll('.mobile-nav-link, .mobile-nav-sub').forEach(n => {
          if (!n.classList.contains('mobile-nav-expandable')) n.classList.remove('active');
        });
        link.classList.add('active');
      });
    });
  });

  // Add copy button to each code block body
  document.querySelectorAll('.code-block-body').forEach(body => {
    const btn = document.createElement('button');
    btn.className = 'code-copy-btn';
    btn.textContent = '\u{1F4CB} Copy';
    body.appendChild(btn);

    btn.addEventListener('click', () => {
      const pre = body.querySelector('pre');
      const text = pre.textContent;
      navigator.clipboard.writeText(text).then(() => {
        btn.classList.add('copied');
        btn.textContent = '\u2714 Copied!';
        setTimeout(() => {
          btn.classList.remove('copied');
          btn.textContent = '\u{1F4CB} Copy';
        }, 2000);
      });
    });
  });
});
