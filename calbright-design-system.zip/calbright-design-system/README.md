# Calbright Design System

A lightweight design system prototype for Calbright College.

## Includes
- Brand assets
- CSS styles
- UI patterns
- Icons
- Basic interaction scripts

## Structure
- `index.html` – main entry
- `css/styles.css` – styles
- `js/main.js` – interactions
- `images/` – logos and icons

## Run locally
Open `index.html` in a browser.
